var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// declarar variables y objetos sprite

var limite1 = createSprite(200, 100, 400, 2);
var limite2 = createSprite(200, 300, 400, 2);
var casaSam = createSprite(25, 200, 50, 200);
var tienda = createSprite(375, 200, 50, 200);
var sam = createSprite(25, 200, 20, 20);
var auto1 = createSprite(120, 110, 15, 15);
var auto2 = createSprite(180, 290, 15, 15);
var auto3 = createSprite(240, 110, 15, 15);
var auto4 = createSprite(300, 290, 15, 15);
var intentos = 0;


// Pintar
sam.shapeColor = "green";
auto1.shapeColor = "red"
auto2.shapeColor = "red"
auto3.shapeColor = "red"
auto4.shapeColor = "red"
casaSam.shapeColor = "skyblue"
tienda.shapeColor = "yellow"

// Velocidad de los autos
auto1.velocityY = +5
auto2.velocityY = -5
auto3.velocityY = +5
auto4.velocityY = -5


createEdgeSprites();



function draw() {
 background("white");
 stroke("blue")
 textSize(20);
 text("INTENTOS: "+intentos, 160, 50)
 // Rebotes
 auto1.bounceOff(limite1)
 auto1.bounceOff(limite2)
 
 auto2.bounceOff(limite1)
 auto2.bounceOff(limite2)
 
 auto3.bounceOff(limite1)
 auto3.bounceOff(limite2)
 
 auto4.bounceOff(limite1)
 auto4.bounceOff(limite2)
 
 // Movimiento de Sam
 
 if (keyDown("right")){
   sam.velocityX = 2
 }
 
 if (keyDown("LEFT")){
   sam.velocityX = -2
 }
 
 // Sam regresa a la posicioón original cuando se estrella.
 if (sam.isTouching(auto1)){
   sam.x = 25
   sam.y = 200
   intentos = intentos +1
   playSound( "assets/category_hits/retro_game_simple_impact_1.mp3")
 }
 
  if (sam.isTouching(auto2)){
   sam.x = 25
   sam.y = 200
   intentos = intentos +1
   playSound( "assets/category_hits/retro_game_simple_impact_1.mp3")
 }
 
  if (sam.isTouching(auto3)){
   sam.x = 25
   sam.y = 200
   intentos = intentos +1
   playSound( "assets/category_hits/retro_game_simple_impact_1.mp3")
 }
 
  if (sam.isTouching(auto4)){
   sam.x = 25
   sam.y = 200
   intentos = intentos +1
   playSound( "assets/category_hits/retro_game_simple_impact_1.mp3")
 }

if (sam.isTouching(tienda)){
auto1.destroy()
auto2.destroy()
auto3.destroy()
auto4.destroy()
text("GANASTE!", 160, 200);
}

 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
